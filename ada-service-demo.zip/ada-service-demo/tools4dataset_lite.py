﻿import asyncio
import json
from datetime import datetime, timedelta, timezone
from typing import Optional, Type

import requests
import websockets
from langchain.callbacks.manager import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain.tools import BaseTool
from pydantic import BaseModel, Field

class ImSendMsgInput(BaseModel):
    App: Optional[str] = Field()
    Receiver: str = Field()
    Msg: str = Field()


class ImSendMsgTool(BaseTool):
    name: str = "ImSendMsg"
    description: str = ""
    args_schema: Type[BaseModel] = ImSendMsgInput

    def _run(
        self,
        App: Optional[str],
        Receiver: str,
        Msg: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Use the tool."""
        result = ""
        print(f"ImSendMsgTool: Receiver:{Receiver}, Msg:{Msg}, App:{App}")
        return "done"

class ImReadMsgInput(BaseModel):
    App: Optional[str] = Field()
    Receiver: str = Field()
    Type: Optional[str] = Field()


class ImReadMsgTool(BaseTool):
    name: str = "ImReadMsg"
    description: str = ""
    args_schema: Type[BaseModel] = ImReadMsgInput

    def _run(
        self,
        App: Optional[str],
        Receiver: str,
        Type: Optional[str],
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Use the tool."""
        result = ""
        print(f"ImReadMsgTool: Receiver:{Receiver}, App:{App}")
        return "done"


class NoteCreateInput(BaseModel):

    Msg: str = Field()



class NoteCreateTool(BaseTool):
    name: str = "NoteCreate"
    description: str = ""
    args_schema: Type[BaseModel] = NoteCreateInput

    def _run(
        self,

        Msg: str,
    ) -> str:
        """Use the tool."""
        result = ""
        print(f"NoteCreateTool: Msg:{Msg}")
        return "done"



class ScheduleCreateInput(BaseModel):

    Msg: str = Field()
    Time: str = Field()


class ScheduleCreateTool(BaseTool):
    name: str = "ScheduleCreate"
    description: str = ""
    args_schema: Type[BaseModel] = ScheduleCreateInput

    def _run(
        self,

        Msg: str,
        Time: str,
    ) -> str:
        """Use the tool."""
        result = ""
        print(f"ScheduleCreateTool: Msg:{Msg},Time:{Time}")
        return "done"

